from distutils.core import setup

setup(
    name='oc_python_nester',
    version='1.4.0',
    py_modules=['nester'],
    author='oc_python',
    author_email='chenlfc@126.com',
    url='http://ocpython.wordpress.com',
    description='一个简单的列表内容输出模块，添加了用于输出到不同位置的选项',
)
