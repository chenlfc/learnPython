from distutils.core import setup

setup(
    name='oc_python_nester',
    version='1.3.0',
    py_modules=['nester'],
    author='oc_python',
    author_email='chenlfc@126.com',
    url='http://www.126.com',
    description='一个简单的列表内容输出模块',
)
